

<?php $__env->startSection('light-box-comment_area'); ?>
    <div class="light-box-comment_area">
        <span>共有10則評論</span>
        <div class="comment_wrap">
            <!-- <div class="comment_row">很漂亮!</div> -->
            <!-- <div class="comment_row">我昨天才到過那裡!</div> -->

            <!-- <img src="" alt=""> -->
            <div class="no_comment">There's no comment right now</div>
        </div>

        <div class="write_comment">
            <form action="">
                <label for="comment">寫下留言</label>
                <textarea name="comment" id="comment"></textarea>

                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('photo.all_photo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/photo_gallery/resources/views/comment/comment.blade.php ENDPATH**/ ?>